document.addEventListener('DOMContentLoaded', () => {
    const fontSelector = document.getElementById('font-family');
    const transcriptContainer = document.getElementById('transcript-container');

    if (fontSelector && transcriptContainer) {
        fontSelector.addEventListener('change', (e) => {
            const selectedFont = e.target.value;
            transcriptContainer.style.fontFamily = selectedFont;
        });
    }
});
